document.querySelector('#keyword').addEventListener('keyup', function() {

    $.ajax({
        url: 'http://127.0.0.1:5000/ajax',
        method: 'post',
        data: { keyword: this.value },
        datatype: 'json',
        success: function(data) {
            const table = document.querySelector('#table_data');
            let tableHTML = "";
            let dataRespon = data.data;
            for (i in dataRespon) {
                tableHTML += '<tr>';
                tableHTML += '<td>' + dataRespon[i][0] + '</td>'
                tableHTML += '<td>' + dataRespon[i][1] + '</td>'
                tableHTML += '<td>' + dataRespon[i][2] + '</td>'
                tableHTML += '</tr>';
                table.innerHTML = tableHTML;
            }
            // Select the whole paragraph
            var ob = new Mark(document.querySelectorAll("#table_data tr td"));

            // First unmark the highlighted word or letter
            ob.unmark();

            // Highlight letter or word

            ob.mark(
                document.querySelector('#keyword').value, {
                    className: 'mark'
                }
            );
            return 0;
        }
    })


})