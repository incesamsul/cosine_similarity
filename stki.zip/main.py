#import library
from flask import Flask, render_template, request, redirect, url_for, flash
from cosine_similarity import top_rank_cs
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from flask_mysqldb import MySQL
import numpy as np
import pandas as pd
import operator

app = Flask(__name__)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASS'] = ''
app.config['MYSQL_DB'] = 'cosine_similarity'

app.secret_key = 'Flash Message'

mysql = MySQL(app)

data = top_rank_cs

@app.route("/", methods=['POST','GET'])
def index():
    dataset = {}
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM document")
    documents = cur.fetchall()
    if request.method == 'POST':
        for document in documents:
            dataset[document[1]] = document[2]
        dataset["q"] = request.form['keyword']
        tfidf = TfidfVectorizer()
        inverted_index = tfidf.fit_transform(dataset.values())
        pd.DataFrame(inverted_index.toarray(), index=dataset.keys(), columns=tfidf.get_feature_names())
        cs = cosine_similarity(inverted_index, inverted_index)
        df_cs = pd.DataFrame(cs, index=dataset.keys(), columns=dataset.keys())
        rank_cs = {}
        for k in dataset.keys():
            if k != "q":
                rank_cs[k] = df_cs.at[k, "q"]
        d = rank_cs
        d2 = dataset
        result = [(k, d2[k], v) for k, v in d.items()]
        top_rank_cs = sorted(result, key=operator.itemgetter(2), reverse=True)
        return render_template('views/home.html', result=top_rank_cs)
    else:
        for document in documents:
            dataset[document[1]] = document[2]
        dataset["q"] = ""
        tfidf = TfidfVectorizer()
        inverted_index = tfidf.fit_transform(dataset.values())
        pd.DataFrame(inverted_index.toarray(), index=dataset.keys(), columns=tfidf.get_feature_names())
        cs = cosine_similarity(inverted_index, inverted_index)
        df_cs = pd.DataFrame(cs, index=dataset.keys(), columns=dataset.keys())
        rank_cs = {}
        for k in dataset.keys():
            if k != "q":
                rank_cs[k] = df_cs.at[k, "q"]
        d = rank_cs
        d2 = dataset
        result = [(k, d2[k], v) for k, v in d.items()]
        return render_template('views/home.html',result=result)

@app.route("/tambah", methods=['POST','GET'])
def tambah():
    if request.method == 'POST':
        document = request.form['document']
        cur = mysql.connection.cursor()
        cur.execute("SELECT code_doc FROM document ORDER BY id DESC LIMIT 1")
        docCodeFetchOne = cur.fetchone()
        if docCodeFetchOne != None:
            docCode = 'D' + str(int(docCodeFetchOne[0][1]) + 1)
        else:
            docCode = 'D1'
        # return render_template('views/tambah.html',docCode=docCode)
        
        cur.execute("INSERT INTO document VALUES ('', %s, %s)", [docCode, document])
        mysql.connection.commit()
        flash("data berhasil di tambah")
        return redirect(url_for('document'))
    return render_template('views/tambah.html')

@app.route("/document")
def document():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM document")
    doc = cur.fetchall()
    return render_template('views/document.html', document=doc)

@app.route('/edit/<string:id>', methods=['POST','GET'])
def edit(id):
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM document WHERE id = %s", [id])
    dataEdit = cur.fetchone()
    if request.method == 'POST':
        docEdit = request.form['document']
        cur.execute("UPDATE document SET document = %s WHERE id = %s", [docEdit,id])
        mysql.connection.commit()
        flash('data berhasil di edit')
        return redirect(url_for('document'))
    return render_template('views/edit.html', edits = dataEdit)

@app.route('/hapus/<string:id>', methods=['POST','GET'])
def hapus(id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM document WHERE id = %s ", [id])
    mysql.connection.commit()
    flash('data berhasil di hapus')
    return redirect(url_for('document'))


@app.route('/ajax', methods=['POST'])
def ajax():
    dataset = {}
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM document")
    documents = cur.fetchall()
    for document in documents:
        dataset[document[1]] = document[2]
    dataset["q"] = request.form['keyword']
    tfidf = TfidfVectorizer()
    inverted_index = tfidf.fit_transform(dataset.values())
    cs = cosine_similarity(inverted_index, inverted_index)
    df_cs = pd.DataFrame(cs, index=dataset.keys(), columns=dataset.keys())
    rank_cs = {}
    for k in dataset.keys():
        if k != "q":
            rank_cs[k] = df_cs.at[k, "q"]
    d = rank_cs
    d2 = dataset
    result = [(k, d2[k], v) for k, v in d.items()]
    top_rank_cs = sorted(result, key=operator.itemgetter(2), reverse=True)
    ajaxResponse = {}
    ajaxResponse['data'] = top_rank_cs
    return ajaxResponse
    # return top_rank_cs
